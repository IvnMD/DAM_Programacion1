package com.docencia.herencia.ejercicio3;

import java.util.UUID;

public class Desarrollador extends Empleado {

    private String lenguajePrincipal;

    public Desarrollador(UUID id, String nombre, double salarioBase, String lenguajePrincipal) {
        super(id, nombre, salarioBase);
        throw new UnsupportedOperationException("El metodo no esta implementado");
}

    public String getLenguajePrincipal() { return lenguajePrincipal; }

    @Override
    public double calcularBonus() {
        return getSalarioBase() * 0.10;
    }

    @Override
    public String toString() {
        throw new UnsupportedOperationException("El metodo no esta implementado");
    }
}
