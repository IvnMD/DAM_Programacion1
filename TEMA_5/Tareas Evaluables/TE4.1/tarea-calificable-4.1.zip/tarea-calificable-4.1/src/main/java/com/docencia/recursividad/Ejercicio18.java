package com.docencia.recursividad;

public class Ejercicio18 {
  /**
   * Merge de dos arreglos ordenados
   * TODO: Implementar usando recursividad.
   */
  public static int[] fusionarOrdenados(int[] a, int[] b) {
    throw new UnsupportedOperationException("Pendiente de implementar");
  }
}
