package com.docente.modelo;

import java.util.Objects;

/**
 * TODO alumnado:
 * Implementa esta clase completa a partir del enunciado del README.
 *
 * Requisitos mínimos:
 * - atributos: codigo, nombre, horasSemanales
 * - constructores
 * - getters y setters
 * - equals y hashCode por codigo
 * - toString
 * - toCsv
 */
public class Asignatura {

    private String codigo;
    private String nombre;
    private int horasSemanales;

    public Asignatura(String codigo) {
        this.codigo = codigo;
    }

    public Asignatura(String codigo, String nombre, int horasSemanales) {
        // TODO implementar
        this.codigo = codigo;
        this.nombre = nombre;
        this.horasSemanales = horasSemanales;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getHorasSemanales() {
        return horasSemanales;
    }

    public void setHorasSemanales(int horasSemanales) {
        this.horasSemanales = horasSemanales;
    }

    public String toCsv() {
        // TODO implementar correctamente
        return codigo + "|" + nombre + "|" + horasSemanales;
    }

    @Override
    public String toString() {
        // TODO mejorar formato si lo consideras necesario
        return "Asignatura [codigo=" + codigo + ", nombre=" + nombre + ", horasSemanales=" + horasSemanales + "]";
    }

    @Override
    public boolean equals(Object obj) {
        // TODO implementar por codigo
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Asignatura other)) {
            return false;
        }
        return Objects.equals(codigo, other.codigo);
    }

    @Override
    public int hashCode() {
        // TODO implementar por codigo
        return Objects.hash(codigo);
    }
}
