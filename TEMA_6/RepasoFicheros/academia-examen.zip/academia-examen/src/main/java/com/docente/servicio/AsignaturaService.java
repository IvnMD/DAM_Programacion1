package com.docente.servicio;

import com.docente.modelo.Asignatura;
import com.docente.persistencia.IAsignaturaRepositorio;
import com.docente.persistencia.impl.AsignaturaRepositorioCSV;

import java.util.ArrayList;
import java.util.List;


public class AsignaturaService implements IAsignaturaService {

    private final IAsignaturaRepositorio asignaturaRepositorio;
    private final List<Asignatura> asignaturas;

    public AsignaturaService() {
        this(new AsignaturaRepositorioCSV());
    }

    public AsignaturaService(IAsignaturaRepositorio asignaturaRepositorio) {
        this.asignaturaRepositorio = asignaturaRepositorio;
        this.asignaturas = new ArrayList<>(asignaturaRepositorio.obtenerAsignaturas());
    }

    @Override
    public List<String> read() {
        // TODO implementar
        return new ArrayList<>();
    }

    public boolean updateLista() {
        // TODO implementar
        return false;
    }

    @Override
    public boolean crearAsignatura(String codigo, String nombre, int horasSemanales) {
        // TODO implementar validaciones, duplicados y guardado
        return false;
    }

    @Override
    public boolean actualizarAsignatura(String codigo, String nombre, int horasSemanales) {
        // TODO implementar
        return false;
    }

    @Override
    public boolean deleteAsignatura(String codigo) {
        // TODO implementar
        return false;
    }

    @Override
    public Asignatura buscarAsignatura(String codigo) {
        // TODO implementar
        return null;
    }
}
