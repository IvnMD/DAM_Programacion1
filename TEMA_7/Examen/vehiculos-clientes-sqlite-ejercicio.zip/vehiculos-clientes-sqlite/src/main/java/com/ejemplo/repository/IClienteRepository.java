package com.ejemplo.repository;

import com.ejemplo.model.Cliente;
import java.util.List;

public interface IClienteRepository {
    /**
     * Crea un nuevo cliente en la base de datos.
     * @param cliente cleinte a crear
     * @return true si se creo correctamente,  
     */
    boolean create(Cliente cliente);
    List<Cliente> findAll();
    Cliente findById(String dni);
    boolean update(Cliente cliente);
    boolean deleteById(String dni);
}
