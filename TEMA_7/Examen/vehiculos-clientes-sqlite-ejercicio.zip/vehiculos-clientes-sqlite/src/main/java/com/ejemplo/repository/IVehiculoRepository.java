package com.ejemplo.repository;

import com.ejemplo.model.Vehiculo;
import java.util.List;

public interface IVehiculoRepository {
    boolean create(Vehiculo vehiculo);
    List<Vehiculo> findAll();
    Vehiculo findById(Long id);
    boolean update(Vehiculo vehiculo);
    boolean deleteById(Long id);
}
