package com.ejemplo.service;

import com.ejemplo.model.Cliente;
import com.ejemplo.repository.IClienteRepository;
import com.ejemplo.repository.sqlite.ClienteSqliteRepository;

import java.util.ArrayList;
import java.util.List;

public class ClienteService implements IClienteService {

    private final IClienteRepository repository;


    public ClienteService() {
        this.repository = new ClienteSqliteRepository();
    }


    @Override
    public boolean crear(Cliente cliente) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'crear'");
    }


    @Override
    public Cliente buscarPorDni(String dni) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'buscarPorDni'");
    }


    @Override
    public List<Cliente> listarTodos() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'listarTodos'");
    }


    @Override
    public boolean actualizar(Cliente cliente) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'actualizar'");
    }


    @Override
    public boolean eliminar(String dni) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'eliminar'");
    }


    @Override
    public List<Cliente> listarActivos() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'listarActivos'");
    }


    @Override
    public List<Cliente> buscarPorCiudad(String ciudad) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'buscarPorCiudad'");
    }


    @Override
    public int contarActivos() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'contarActivos'");
    }

    
}
