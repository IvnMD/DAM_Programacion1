package com.ejemplo.service;

import com.ejemplo.model.Cliente;
import java.util.List;

/**
 * API de servicios para la gestion de clientes.
 */
public interface IClienteService {

    boolean crear(Cliente cliente);
    Cliente buscarPorDni(String dni);
    List<Cliente> listarTodos();
    boolean actualizar(Cliente cliente);
    boolean eliminar(String dni);
    List<Cliente> listarActivos();
    List<Cliente> buscarPorCiudad(String ciudad);
    int contarActivos();
}
