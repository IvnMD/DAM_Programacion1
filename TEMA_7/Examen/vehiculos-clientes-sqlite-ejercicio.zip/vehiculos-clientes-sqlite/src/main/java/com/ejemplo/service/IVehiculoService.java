package com.ejemplo.service;

import com.ejemplo.model.Vehiculo;
import java.util.List;


public interface IVehiculoService {

    boolean crear(Vehiculo vehiculo);
    Vehiculo buscarPorId(Long id);
    List<Vehiculo> listarTodos();
    boolean actualizar(Vehiculo vehiculo);
    boolean eliminar(Long id);
    List<Vehiculo> listarPorCliente(String dni);
    List<Vehiculo> listarVendidos();
    List<Vehiculo> listarDisponibles();
    boolean cambiarPropietario(Long vehiculoId, String nuevoDni);
    boolean marcarComoVendido(Long vehiculoId);
    boolean actualizarKilometros(Long vehiculoId, int kilometros);
    double calcularPrecioMedio();
    public double calcularValorTotalDisponible();
    public int contarVehiculosDeCliente(String dniCliente);
}
