package com.ejemplo.service;

import com.ejemplo.model.Vehiculo;
import com.ejemplo.repository.IClienteRepository;
import com.ejemplo.repository.IVehiculoRepository;
import com.ejemplo.repository.sqlite.ClienteSqliteRepository;
import com.ejemplo.repository.sqlite.VehiculoSqliteRepository;

import java.util.ArrayList;
import java.util.List;

public class VehiculoService implements IVehiculoService {

    private final IVehiculoRepository vehiculoRepository;
    private final IClienteRepository clienteRepository;

    public VehiculoService() {
        this.vehiculoRepository = new VehiculoSqliteRepository();
        this.clienteRepository = new ClienteSqliteRepository(); 
    }

    @Override
    public boolean crear(Vehiculo vehiculo) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'crear'");
    }

    @Override
    public Vehiculo buscarPorId(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'buscarPorId'");
    }

    @Override
    public List<Vehiculo> listarTodos() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'listarTodos'");
    }

    @Override
    public boolean actualizar(Vehiculo vehiculo) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'actualizar'");
    }

    @Override
    public boolean eliminar(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'eliminar'");
    }

    @Override
    public List<Vehiculo> listarPorCliente(String dni) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'listarPorCliente'");
    }

    @Override
    public List<Vehiculo> listarVendidos() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'listarVendidos'");
    }

    @Override
    public List<Vehiculo> listarDisponibles() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'listarDisponibles'");
    }

    @Override
    public boolean cambiarPropietario(Long vehiculoId, String nuevoDni) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'cambiarPropietario'");
    }

    @Override
    public boolean marcarComoVendido(Long vehiculoId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'marcarComoVendido'");
    }

    @Override
    public boolean actualizarKilometros(Long vehiculoId, int kilometros) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'actualizarKilometros'");
    }

    @Override
    public double calcularPrecioMedio() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'calcularPrecioMedio'");
    }

    @Override
    public double calcularValorTotalDisponible() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'calcularValorTotalDisponible'");
    }

    @Override
    public int contarVehiculosDeCliente(String dniCliente) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'contarVehiculosDeCliente'");
    }

    }
