package es.ies.puerto.repositories.sqlite;

import es.ies.puerto.models.Inscripcion;
import es.ies.puerto.repositories.InscripcionRepositoryInterface;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class InscripcionSqliteRepository implements InscripcionRepositoryInterface {
    private final SqliteConnectionManager manager;

    public InscripcionSqliteRepository() {
        this(new SqliteConnectionManager());
    }

    public InscripcionSqliteRepository(SqliteConnectionManager manager) {
        this.manager = manager;
        new DatabaseInitializer(manager).createTables();
    }

    @Override
    public List<Inscripcion> findAll() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

    @Override
    public Inscripcion findById(int id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }

    @Override
    public List<Inscripcion> findByUsuario(int idUsuario) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByUsuario'");
    }

    @Override
    public List<Inscripcion> findByActividad(int idActividad) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByActividad'");
    }

    @Override
    public boolean save(Inscripcion inscripcion) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'save'");
    }

    @Override
    public boolean update(Inscripcion inscripcion) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public boolean delete(int id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }

    
}
