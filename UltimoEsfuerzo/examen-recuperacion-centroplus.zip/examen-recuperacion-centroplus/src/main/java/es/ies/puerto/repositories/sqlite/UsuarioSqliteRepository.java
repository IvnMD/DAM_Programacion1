package es.ies.puerto.repositories.sqlite;

import es.ies.puerto.models.Usuario;
import es.ies.puerto.repositories.UsuarioRepositoryInterface;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioSqliteRepository implements UsuarioRepositoryInterface {
    private final SqliteConnectionManager manager;

    public UsuarioSqliteRepository() {
        this(new SqliteConnectionManager());
    }

    public UsuarioSqliteRepository(SqliteConnectionManager manager) {
        this.manager = manager;
        new DatabaseInitializer(manager).createTables();
    }

    @Override
    public List<Usuario> findAll() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

    @Override
    public Usuario findById(int id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }

    @Override
    public boolean save(Usuario usuario) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'save'");
    }

    @Override
    public boolean update(Usuario usuario) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public boolean delete(int id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }

    
}
