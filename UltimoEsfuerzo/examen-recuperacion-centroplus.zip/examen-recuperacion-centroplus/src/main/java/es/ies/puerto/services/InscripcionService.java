package es.ies.puerto.services;

import es.ies.puerto.models.Constantes;

import es.ies.puerto.models.Actividad;
import es.ies.puerto.models.Inscripcion;
import es.ies.puerto.repositories.ActividadRepositoryInterface;
import es.ies.puerto.repositories.InscripcionRepositoryInterface;
import es.ies.puerto.repositories.UsuarioRepositoryInterface;

import java.time.LocalDate;
import java.util.List;

public class InscripcionService implements InscripcionServiceInterface {
    private final InscripcionRepositoryInterface inscripcionRepository;
    private final UsuarioRepositoryInterface usuarioRepository;
    private final ActividadRepositoryInterface actividadRepository;

    public InscripcionService(InscripcionRepositoryInterface inscripcionRepository,
                              UsuarioRepositoryInterface usuarioRepository,
                              ActividadRepositoryInterface actividadRepository) {
        this.inscripcionRepository = inscripcionRepository;
        this.usuarioRepository = usuarioRepository;
        this.actividadRepository = actividadRepository;
    }



    @Override
    public boolean update(Inscripcion inscripcion) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public boolean delete(int id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }



    @Override
    public List<Inscripcion> findAll() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }



    @Override
    public Inscripcion findById(int id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }



    @Override
    public List<Inscripcion> findByUsuario(int idUsuario) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByUsuario'");
    }



    @Override
    public List<Inscripcion> findByActividad(int idActividad) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByActividad'");
    }



    @Override
    public boolean save(Inscripcion inscripcion) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'save'");
    }



    @Override
    public boolean cancelar(int id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'cancelar'");
    }
}
