package com.ejemplo.repository;

import com.ejemplo.model.Alquiler;
import java.time.LocalDate;
import java.util.List;

public interface IAlquilerRepository {
    
}
