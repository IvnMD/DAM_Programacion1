package com.ejemplo.repository;

import com.ejemplo.model.Cliente;
import java.util.List;

public interface IClienteRepository {

}
