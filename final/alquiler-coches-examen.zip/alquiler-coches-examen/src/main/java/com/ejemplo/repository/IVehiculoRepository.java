package com.ejemplo.repository;

import com.ejemplo.model.Vehiculo;
import java.util.List;

public interface IVehiculoRepository {

}
