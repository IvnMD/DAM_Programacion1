package com.ejemplo.repository.sqlite;

import com.ejemplo.model.Alquiler;
import com.ejemplo.repository.IAlquilerRepository;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AlquilerSqliteRepository implements IAlquilerRepository {
    
}
