package com.ejemplo.repository.sqlite;

import com.ejemplo.model.Cliente;
import com.ejemplo.repository.IClienteRepository;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteSqliteRepository implements IClienteRepository {
    
}
