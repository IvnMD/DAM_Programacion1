package com.ejemplo.repository.sqlite;

import com.ejemplo.model.Vehiculo;
import com.ejemplo.repository.IVehiculoRepository;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VehiculoSqliteRepository implements IVehiculoRepository {
    
}
