package com.ejemplo.service;

import com.ejemplo.model.Alquiler;
import com.ejemplo.model.Cliente;
import com.ejemplo.model.Vehiculo;
import com.ejemplo.repository.IAlquilerRepository;
import com.ejemplo.repository.IClienteRepository;
import com.ejemplo.repository.IVehiculoRepository;
import com.ejemplo.repository.sqlite.AlquilerSqliteRepository;
import com.ejemplo.repository.sqlite.ClienteSqliteRepository;
import com.ejemplo.repository.sqlite.VehiculoSqliteRepository;
import com.ejemplo.validation.ValidationUtils;
import java.time.LocalDate;
import java.util.List;

public class AlquilerService implements IAlquilerService {
    private final IAlquilerRepository repository;
    private final IClienteRepository clienteRepository;
    private final IVehiculoRepository vehiculoRepository;

    public AlquilerService() {
        this.repository = new AlquilerSqliteRepository();
        this.clienteRepository = new ClienteSqliteRepository();
        this.vehiculoRepository = new VehiculoSqliteRepository();
    }

    @Override
    public boolean create(Alquiler alquiler) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'create'");
    }

    @Override
    public Alquiler findById(Integer id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }

    @Override
    public List<Alquiler> findAll() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

    @Override
    public boolean cancelById(Integer id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'cancelById'");
    }

    @Override
    public boolean completeById(Integer id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'completeById'");
    }

    @Override
    public List<Alquiler> findByCliente(String dniCliente) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByCliente'");
    }

    @Override
    public List<Alquiler> findByVehiculo(Integer idVehiculo) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByVehiculo'");
    }

    @Override
    public boolean existsActiveRental(String dniCliente, Integer idVehiculo, LocalDate fechaInicio,
            LocalDate fechaFin) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'existsActiveRental'");
    }


}
