package com.ejemplo.validation;

import java.time.LocalDate;

public final class ValidationUtils {
    private ValidationUtils() {}

    public static boolean isValidDni(String dni) {
        return false;
    }

    public static boolean isValidEmail(String email) {
        return false;
    }

    public static boolean isValidTelefono(String telefono) {
        return false;
    }

    public static boolean isValidTexto(String texto) {
        return false;
    }

    public static boolean isValidActivo(int activo) {
        return false;
    }

    public static boolean isValidTipoVehiculo(String tipo) {
        return false;
    }

    public static boolean isValidEstadoAlquiler(String estado) {
        return false;
    }

    public static boolean isValidFutureStart(LocalDate fechaInicio) {
        return false;
    }

    public static boolean isValidDateRange(LocalDate inicio, LocalDate fin) {
        return false;
    }
}
