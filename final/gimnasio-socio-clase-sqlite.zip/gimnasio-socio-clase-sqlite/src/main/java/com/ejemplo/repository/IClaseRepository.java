package com.ejemplo.repository;

import com.ejemplo.model.Clase;
import com.ejemplo.model.ClaseMonitor;
import com.ejemplo.model.ClaseReservaSocio;

import java.util.List;

public interface IClaseRepository {

}
