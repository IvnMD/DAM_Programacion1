package com.ejemplo.repository;

import com.ejemplo.model.Socio;
import com.ejemplo.model.SocioReserva;

import java.util.List;

public interface ISocioRepository {

}
