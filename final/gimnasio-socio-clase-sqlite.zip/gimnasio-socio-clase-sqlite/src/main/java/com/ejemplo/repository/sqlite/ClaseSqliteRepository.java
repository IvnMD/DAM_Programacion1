package com.ejemplo.repository.sqlite;

import com.ejemplo.model.Clase;
import com.ejemplo.model.ClaseMonitor;
import com.ejemplo.model.ClaseReservaSocio;
import com.ejemplo.repository.IClaseRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClaseSqliteRepository extends SQLiteConnectionManager implements IClaseRepository {
    
    public ClaseSqliteRepository() {
    
    }

}
