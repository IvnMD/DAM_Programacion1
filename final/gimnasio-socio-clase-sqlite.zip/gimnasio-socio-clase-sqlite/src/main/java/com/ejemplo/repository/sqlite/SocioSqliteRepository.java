package com.ejemplo.repository.sqlite;

import com.ejemplo.model.Socio;
import com.ejemplo.model.SocioReserva;
import com.ejemplo.repository.ISocioRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SocioSqliteRepository extends SQLiteConnectionManager implements ISocioRepository {


    public SocioSqliteRepository() {
    }

    }
