package com.ejemplo.service;

import com.ejemplo.model.Clase;
import com.ejemplo.model.ClaseMonitor;
import com.ejemplo.model.ClaseReservaSocio;
import com.ejemplo.repository.IClaseRepository;

import java.util.List;

public class ClaseService implements IClaseService {

    private final IClaseRepository repository;

    public ClaseService(IClaseRepository repository) {
        this.repository = repository;
    }

    @Override
    public boolean create(Clase clase) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'create'");
    }

    @Override
    public Clase findById(Integer id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }

    @Override
    public List<Clase> findAll() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

    @Override
    public boolean update(Clase clase) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public boolean deleteById(Integer id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteById'");
    }

    @Override
    public List<Clase> findDisponibles() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findDisponibles'");
    }

    @Override
    public List<Clase> findByTipo(String tipo) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByTipo'");
    }

    @Override
    public List<Clase> findByMonitor(Integer idMonitor) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByMonitor'");
    }

    @Override
    public List<ClaseMonitor> findClasesConMonitor() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findClasesConMonitor'");
    }

    @Override
    public List<ClaseReservaSocio> findReservasConSocio() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findReservasConSocio'");
    }

   
}
